package qlsv.model;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Lớp trừu tượng cho mọi tài khoản trong hệ thống.
 * Mật khẩu chỉ được lưu dưới dạng chuỗi băm PBKDF2 (kèm salt), không có
 * thuộc tính nào giữ mật khẩu gốc.
 */
public abstract class User implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String username;
    private String passwordHash;
    private int failedAttempts;
    private LocalDateTime lockedUntil;
    private LocalDateTime lastLogin;
    private LocalDateTime previousLogin;
    private boolean mustChangePassword;

    protected User(String username, String passwordHash) {
        this.username = username;
        this.passwordHash = passwordHash;
    }

    /** Tên vai trò hiển thị trên giao diện (đa hình). */
    public abstract String getRoleName();

    /** Họ tên hiển thị. */
    public abstract String getDisplayName();

    /** Vai trò quản trị hay không, dùng cho kiểm soát truy cập. */
    public abstract boolean isAdmin();

    public String getUsername() { return username; }

    public String getPasswordHash() { return passwordHash; }

    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public int getFailedAttempts() { return failedAttempts; }

    public void setFailedAttempts(int failedAttempts) { this.failedAttempts = failedAttempts; }

    public LocalDateTime getLockedUntil() { return lockedUntil; }

    public void setLockedUntil(LocalDateTime lockedUntil) { this.lockedUntil = lockedUntil; }

    public boolean isLocked(LocalDateTime now) {
        return lockedUntil != null && lockedUntil.isAfter(now);
    }

    public LocalDateTime getLastLogin() { return lastLogin; }

    public LocalDateTime getPreviousLogin() { return previousLogin; }

    /** Ghi nhận một lần đăng nhập thành công, giữ lại thời điểm lần trước. */
    public void recordLogin(LocalDateTime now) {
        this.previousLogin = this.lastLogin;
        this.lastLogin = now;
    }

    public boolean isMustChangePassword() { return mustChangePassword; }

    public void setMustChangePassword(boolean mustChangePassword) { this.mustChangePassword = mustChangePassword; }
}
