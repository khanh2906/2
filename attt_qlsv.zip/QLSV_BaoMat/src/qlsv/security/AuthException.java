package qlsv.security;

/** Lỗi xác thực, mang lý do cụ thể để giao diện hiển thị thông báo phù hợp. */
public class AuthException extends Exception {
    private static final long serialVersionUID = 1L;

    public enum Reason {
        /** Sai tên đăng nhập hoặc mật khẩu (không phân biệt, chống dò tài khoản). */
        INVALID_CREDENTIALS,
        /** Tài khoản đang bị khoá tạm thời. */
        LOCKED,
        /** Xác thực lại thất bại khi thực hiện thao tác nhạy cảm. */
        REAUTH_FAILED
    }

    private final Reason reason;
    private final long minutesLeft;

    public AuthException(Reason reason, long minutesLeft) {
        super(reason.name());
        this.reason = reason;
        this.minutesLeft = minutesLeft;
    }

    public Reason getReason() { return reason; }

    public long getMinutesLeft() { return minutesLeft; }
}
