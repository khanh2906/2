package qlsv.security;

/** Dữ liệu nhập vào không hợp lệ; thông điệp hiển thị trực tiếp cho người dùng. */
public class ValidationException extends Exception {
    private static final long serialVersionUID = 1L;

    public ValidationException(String message) {
        super(message);
    }
}
