package qlsv.data;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

/** Trừu tượng hoá tầng lưu trữ: phần nghiệp vụ không phụ thuộc cách ghi file. */
public interface DataHandler {

    <T extends Serializable> void save(List<T> items, String fileName) throws IOException;

    <T extends Serializable> List<T> load(String fileName, Class<T> type) throws IOException, IntegrityException;

    boolean exists(String fileName);

    /** Kiểm tra chữ ký HMAC của một file. */
    boolean verify(String fileName);

    /** Khôi phục file từ bản sao lưu gần nhất (nếu bản sao lưu còn nguyên vẹn). */
    boolean restoreBackup(String fileName);
}
