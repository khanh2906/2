# QLSV Bảo Mật — Ứng dụng quản lý sinh viên bảo mật (Java Swing)

Đồ án học phần **An toàn thông tin**. Ứng dụng desktop quản lý sinh viên, điểm và tài khoản,
trong đó mọi chức năng đều được thiết kế theo các nguyên tắc bảo mật: băm mật khẩu, mã hoá
dữ liệu nhạy cảm, khoá tài khoản khi dò mật khẩu, phân quyền, nhật ký kiểm toán và kiểm tra
toàn vẹn dữ liệu. Giao diện theo bố cục của project Quản lý thư viện (Java Swing).

## Yêu cầu
- JDK 11 trở lên (khuyến nghị JDK 17 hoặc 21). Không cần thư viện ngoài.

## Cách chạy
| Cách | Thao tác |
|---|---|
| Chạy nhanh | Nháy đúp `QLSV_BaoMat.jar` hoặc `java -jar QLSV_BaoMat.jar` |
| Từ mã nguồn (Windows) | Nháy đúp `chay.bat` |
| Từ mã nguồn (macOS/Linux) | `./chay.sh` |
| NetBeans | New Project → Java with Ant → *Java Project with Existing Sources* → chọn `src` (và `test`) → Main class `qlsv.Main` |
| IntelliJ IDEA | Open thư mục → đánh dấu `src` là Sources Root, `test` là Test Sources Root → chạy `qlsv.Main` |

Lần chạy đầu, ứng dụng tự tạo thư mục `data/` gồm khoá bí mật `secret.key` và dữ liệu mẫu.
Muốn khởi tạo lại từ đầu: tắt ứng dụng rồi **xoá toàn bộ thư mục `data/`**.

## Tài khoản demo
| Tài khoản | Mật khẩu | Ghi chú |
|---|---|---|
| `admin` | `Admin@2026` | Quản trị viên |
| `sv001` … `sv023` | `Sinhvien@2026` | Sinh viên đã kích hoạt |
| `sv024`, `sv025` | `Sinhvien@2026` | Chờ kích hoạt: bắt buộc cập nhật thông tin + đổi mật khẩu |

Mật khẩu demo dùng chung để tiện thuyết trình; mỗi tài khoản vẫn có salt riêng nên chuỗi băm khác nhau.

## Kiểm thử tự động
Chạy `kiemthu.bat` (Windows) hoặc `./kiemthu.sh`. Bộ kiểm thử gồm 37 ca: lưu trữ mật khẩu,
mã hoá CCCD, khoá tài khoản, chính sách mật khẩu, phân quyền/IDOR, quên mật khẩu, kích hoạt
lần đầu, phát hiện sửa/xoá file dữ liệu và bộ lọc giải tuần tự hoá.

## Cơ chế bảo mật chính
| Mối đe doạ | Biện pháp | Lớp cài đặt |
|---|---|---|
| Lộ file dữ liệu → lộ mật khẩu | PBKDF2-HMAC-SHA256, salt 16 byte, 120 000 vòng | `PasswordHasher` |
| Lộ CCCD, số điện thoại | AES-256-GCM, IV ngẫu nhiên; che trên giao diện; xem đầy đủ phải nhập lại mật khẩu | `CryptoService`, `StudentController` |
| Dò mật khẩu (brute-force) | Khoá 15 phút sau 5 lần sai; thông báo lỗi chung; chính sách mật khẩu mạnh | `StudentController`, `InputValidator` |
| Sinh viên xem dữ liệu người khác (IDOR) | Kiểm tra quyền ở tầng controller cho từng thao tác | `StudentController` |
| Sửa / xoá file dữ liệu ngoài ứng dụng | Chữ ký HMAC-SHA256, bản sao lưu `.bak`, tự khôi phục và cảnh báo | `DataManager` |
| Tấn công giải tuần tự hoá | Kiểm chữ ký trước khi đọc + bộ lọc chỉ cho phép lớp của hệ thống | `DataManager` |
| Bỏ quên máy đang đăng nhập | Tự đăng xuất sau 5 phút không thao tác | `SessionGuard` |
| Chối bỏ / không truy vết được | Nhật ký kiểm toán có mức độ, ghi giá trị cũ → mới khi sửa điểm | `StudentController`, `LogEntry` |

## Cấu trúc
```
QLSV_BaoMat/
├── src/qlsv/
│   ├── Main.java
│   ├── model/        User, Admin, Student, Grade, LogEntry, LogLevel
│   ├── security/     PasswordHasher, CryptoService, InputValidator, AuthException, ValidationException
│   ├── data/         DataHandler, DataManager, DataSeeder, IntegrityException
│   ├── controller/   StudentController
│   └── view/         WindowView, LoginFrame, AdminFrame, StudentFrame, các hộp thoại, SessionGuard, UiUtils
├── test/qlsv/SelfTest.java
├── QLSV_BaoMat.jar
├── chay.bat / chay.sh
└── kiemthu.bat / kiemthu.sh
```

> Không đưa thư mục `data/` (chứa `secret.key`) lên Git hay gửi kèm bài nộp.
